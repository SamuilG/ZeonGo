@extends('layouts.app')

@section('headContent')
    <link rel="stylesheet" href="/css/auth.css">
@endsection

@section('content')

{{-- <div class="middle"> --}}
    <img id="logo" src="/images/ZeonGoLogo.png" class="position-absolute top-50 start-50 translate-middle img-fluid">
{{-- </div> --}}
    
@endsection