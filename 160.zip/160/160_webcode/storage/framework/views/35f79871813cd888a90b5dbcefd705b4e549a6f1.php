<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="/css/auth.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <img id="logo" src="/images/ZeonGoLogo.png" class="position-absolute top-50 start-50 translate-middle img-fluid">

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/index.blade.php ENDPATH**/ ?>