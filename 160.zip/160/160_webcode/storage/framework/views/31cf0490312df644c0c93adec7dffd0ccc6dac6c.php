<?php $__env->startSection('title'); ?>
    Devices
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="bg-light row">
        <h1 class="mx-4 my-3 col-4 titlesAdmin"><i class="fa fa-video"></i><span>Devices</span></h1>
        <a class="btn btn-success col-3 my-4 ms-auto me-4" href="/admin/devices/create">Create Device</a>
    </div>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success mx-auto col-4" role="alert">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-striped">
        <tr>
            <th>Device key</th>
            <th>Name</th>
            <th>Location</th>
            <th>Users with pass</th>
            <th>Managers</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        <tr>
            <form action="/admin/devices" method="GET">
                <td><input type="text" name="search_device_key" value='<?php echo e(request()->get('search_id')); ?>' placeholder="Search by id" class="form-control"></td>
                <td><input type="text" name="search_name" value='<?php echo e(request()->get('search_name')); ?>' placeholder="Search by name" class="form-control "></td>
                <td></td>
                <td></td>
                <td></td>
                <td><input type="submit" value="Search" class="btn btn-primary w-100"></td>
                <td><a href="/admin/devices" class="btn btn-danger w-100">Reset</a></td>
            </form>
        </tr>
        <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($device->device_key); ?></td>
                <td><?php echo e($device->device_name); ?></td>
                <td><?php echo e($device->coordinates); ?></td>
                <td><?php echo e($device->users->count()); ?></td>
                <td><?php echo e($device->managers->count()); ?></td>
                <td><a class="btn btn-success w-100" href="/admin/devices/edit/<?php echo e($device->uuid); ?>">Edit</a></td>
                <td>
                    <form action="/admin/devices/destroy/<?php echo e($device->uuid); ?>" method="POST">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Delete" class="btn btn-danger w-100">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </table>
    <div class="w-100">
        <div class="mx-auto">
            <?php echo e($devices->links()); ?>

        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/devices/index.blade.php ENDPATH**/ ?>