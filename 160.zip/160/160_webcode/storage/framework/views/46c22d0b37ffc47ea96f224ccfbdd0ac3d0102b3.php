<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="bg-light row">
        <h1 class="mx-4 my-3"><i class="fa fa-chart-line"></i><span>Dashboard</span></h1>
    </div>
    <div class="row">
        <div class="p-4">
            <div class="card">
                <div class="card-body">
                    <h5>Statistics</h5>
                    <table class="table table-striped">
                        <tr>
                            <td>Total Users:</td>
                            <td><?php echo e($users->count()); ?></td>
                        </tr>
                        <tr>
                            <td>Total Devices</td>
                            <td><?php echo e($devices->count()); ?></td>
                        </tr>
                        <tr>
                            <td>All time usage:</td>
                            <td><?php echo e($history->count()); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/index.blade.php ENDPATH**/ ?>