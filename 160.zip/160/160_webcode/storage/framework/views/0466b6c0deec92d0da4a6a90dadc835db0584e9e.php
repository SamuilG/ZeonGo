<?php $__env->startSection('title'); ?>
    Adding Manager 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-10 bg-light" style="height: 100vh; overflow: hidden">
    <div class="bg-light row">
        <h1 class="mx-4 my-3 col-4">Adding Manager</h1>
    </div>
    <br><br><br>
    <?php if(session()->has('info')): ?>
        <div class="alert alert-info mx-auto col-4" role="alert">
            <?php echo e(session()->get('info')); ?>

        </div>
    <?php endif; ?>
    <div class="card col-11 mx-auto py-4">
        <form action="/admin/users/<?php echo e($user->uuid); ?>/managers/store" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Device Key
                            <span class="required">*</span>
                        </label>
                        <input type="text" name="device_key"
                            class="form-control <?php $__errorArgs = ['device_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('device_key')); ?>"
                        >
                        <?php $__errorArgs = ['device_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                    </div>
                </div>
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            User email
                            <span class="required">*</span>
                        </label>
                        <input type="email" name="email" disabled
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e($user->email); ?>"
                        >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4 ms-auto mt-4">
                    <input class="btn btn-success float-end mx-4" type="submit" value="Save">
                    <a href="/admin/users/edit/<?php echo e($user->uuid); ?>" class="btn btn-danger float-end mx-4">Back</a>
                </div>
            </div>
        </form>
    </div>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/managers/userform.blade.php ENDPATH**/ ?>