<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="/css/auth.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="container" class="card position-absolute top-50 start-50 translate-middle text-white bg-dark border-light p-4 col-4">
        
        <div style="text-align: center">
            <?php echo $__env->yieldContent('form'); ?>
        </div>
    </div>

    <?php echo $__env->yieldContent('modal'); ?>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/layouts/auth.blade.php ENDPATH**/ ?>