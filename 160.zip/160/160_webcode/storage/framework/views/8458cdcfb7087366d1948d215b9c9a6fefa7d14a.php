<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="/css/use.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Create Device
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
<div class="">
    <div class="w-50 position-absolute top-50 start-50 translate-middle">
        
        <h3 class="text-center">Creating Device</h3>

        <form action="#" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="form-group changeDeviceGroup"> 
                <label for="device_name" class="form-label">Device name</label>
                <input type="text" class="form-control" id="device_name" name="device_name" value="">
            </div>

            <div class="form-group changeDeviceGroup"> 
                <label for="device_name" class="form-label">Manager email</label>
                <input type="email" class="form-control" id="manager_email" name="manager_email" value="">
            </div>


            
            <div class="form-group changeDeviceGroup">
                <label class="form-label" for="device_description">Device description</label>
                <textarea class="form-control" rows="3" maxlength="600" id="device_description" name="device_description">s</textarea>
            </div>

            
            
            <div class="form-group changeDeviceGroup">
                <label class="form-label" for="coordinates">Device coordinates</label>
                <input type="text" class="form-control" id="coordinates" name="coordinates" value="">
            </div>
            <input type="submit" value="Create" class="btn btn-primary float-end">
        </form>

    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/createDevice.blade.php ENDPATH**/ ?>