<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/png" href="/images/ZeonGoIcon.png"/>
    
    <link rel="stylesheet" href="/bootstrap-5.1.3-dist/css/bootstrap.min.css">
    <script src="/bootstrap-5.1.3-dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="/css/use.css">
    <?php echo $__env->yieldContent('headContent'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>
    
    <div class="container-fluid d-flex h-100 flex-column">

      <div class="row">
        <div class="col">

          <nav class="navbar navbar-expand-lg navbar-light bg-dark">
          
            <a class="ms-3 h-69px navbar-brand" href="/">
              <img class="mh-100 img-fluid" src="/images/ZeonGoLogo.png" alt="ZeonGo">
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav" style="margin-left: auto">
                
              
                <?php if(auth()->guard()->check()): ?>

                
                
                <?php if(auth()->user()->isAdmin()): ?>
                  <li class="nav-item">
                    <form action="<?php echo e(route('admin.index')); ?>" method="GET" class="p-3 inline">
                        <button type="submit" class="me-2 btn btn-outline-light">Admin Panel</button>
                    </form>
                  </li>
                <?php endif; ?>

                

                <li class="nav-item">
                  <div class="p-3 inline">
                    <button class="btn btn-outline-light">Add Pass</button>
                  </div>
                </li>
                <li class="nav-item">
                  <form action="/account" method="GET" class="p-3 inline">
                      <button type="submit" class="me-2 btn btn-outline-light">Account</button>
                  </form>
                </li>
                  <li class="nav-item">
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="p-3 inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="me-2 btn btn-outline-light">Logout</button>
                    </form>
                  </li>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                      <a href="<?php echo e(route('login')); ?>" class="me-2 btn btn-outline-light" role="button" aria-disabled="true">Login</a>
                    </li>  
                    <li class="nav-item">
                      <a href="<?php echo e(route('register')); ?>" class="me-3 btn btn-outline-light" role="button" aria-disabled="true">Register</a>
                    </li>
                <?php endif; ?>  

              </ul>    
            </div>
          </nav>
          
        </div>
      </div>
      

      <?php echo $__env->yieldContent('content'); ?>

    </div>
  </body>
</html><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/layouts/app.blade.php ENDPATH**/ ?>