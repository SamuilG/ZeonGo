<?php $__env->startSection('title'); ?>
    Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row flex-grow-1">
    
    <div class="col-md-6 d-flex h-100 flex-column h-resp">
        <div class="row info p-2">
            <div class="col">
                
                <h3>Search Users</h3>
                <ul class="list-group m-1">
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        <form class="w-100" method="GET">
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-primary float-end" type="submit" value="Search">
                            <input name="user_search" type="email" placeholder="Search for email" class="w-50 form-control <?php $__errorArgs = ['user_search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            
                            <?php if(session('status')): ?>
                                <div class="text-danger">User with this email doesn't exist</div>
                            <?php endif; ?>
                        </form>
                        <a class="btn btn-danger float-end mx-1" href="<?php echo e(route('admin.index')); ?>">Clear</a>
                    </li>

                    
                    <?php
                        $i = 0;
                    ?>
                    <?php if(count($users)): ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $i++;
                                if($i > 3)
                                {
                                    break;
                                }
                            ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                                <div class="w-37">
                                    <p class="m-0"><?php echo e($user->name); ?></p>                            
                                    <p class="m-0"><?php echo e($user->email); ?></p>
                                </div>

                                <form action="/accountAdminSide/<?php echo e($user->uuid); ?>" method="GET">
                                    <input class="btn btn-dark" type="submit" value="More">
                                </form>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                            There are no results
                        </li>
                    <?php endif; ?>
                    
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover"><a href="">View all users  </a></li>
                </ul>

                

            </div>
        </div>
        <div class="row flex-grow-1 p-2 bg-blue">
            <div class="col">
                
                <h3>Stats</h3>
                <ul class="list-group m-1">
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        Number of users: <p class="m-0 text-end"><?php echo e(count($users)); ?></p>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        Number of devices: <p class="m-0 text-end"><?php echo e(count($devices)); ?></p>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        Successful entries <p class="m-0 text-end"><?php echo e(count($history)); ?></p>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        Number of passes<p class="m-0 text-end"><?php echo e(count($passes)); ?></p>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover"><a href="">View full access history</a></li>
                </ul>

                

            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="">
            
            <h3 class="text-center">Devices</h3>
                
                
                <ul class="list-group m-1">
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        <form class="w-100" method="GET">
                            <?php echo csrf_field(); ?>
                            
                                <input class="btn btn-primary float-end" type="submit" value="Search">
                                <input name="device_search" type="text" placeholder="Enter device name" class="w-50 form-control">
                            
                            
                        </form>
                        <a class="btn btn-danger float-end mx-1" href="<?php echo e(route('admin.index')); ?>">Clear</a>
                    </li>
                    <?php
                        $i = 0
                    ?>
                    <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                            if($i > 5)
                            {
                                break;
                            }
                        ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                            <div class="w-37">
                                <p class="m-0"><?php echo e($device->device_name); ?></p>
                                
                                <p class="m-0">Manager: <?php echo e($device->managers()->first()->user->name ?? 'Not set'); ?></p>
                            </div>

                            <div class="w-37 float-end">
                                <p class="m-0 text-end">Device Id: <?php echo e($device->id); ?></p>
                            </div>

                            <form method="POST">
                                <?php echo csrf_field(); ?>
                                <input class="btn btn-dark" type="submit" value="More">
                            </form>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover"><a href="">View all devices</a></li>
                </ul>

        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/admin.blade.php ENDPATH**/ ?>