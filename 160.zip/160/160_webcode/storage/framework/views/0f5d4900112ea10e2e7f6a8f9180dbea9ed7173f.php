<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
        integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
        crossorigin=""/>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
        integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
        crossorigin=""></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row flex-grow-1">
    <div class="qrCode p-2" style="display: none;">
        <img src="<?php echo e($data['key']); ?>" class="img-fluid" alt="The qr code">
    </div>
    <div class="col-md-8 d-flex h-100 flex-column">
        <div class="row locations">
            <div class="col h-100">
                


                
                    <div class="container-fluid h-100 d-flex overflow-auto">
                        <div class="row flex-grow-1 flex-nowrap overflow-auto zoom-zoom">
    
                            <?php $__currentLoopData = $data['devices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-card p-3 ps-2 pe-2 card-zoom">
                                <div class="card h-100 card-block bg-dark">
                                    <div class="card-body overflow-auto">
                                        <h4 class="card-title text-white pb-2"><?php echo e($device->device_name); ?></h4>
                                        <p class="card-text text-white">
                                            
                                            <?php if($data['awaitingUsers']->contains('device_id' ,$device->id)): ?>
                                                <span class="text-danger">There are users awaiting approval</span> <br>
                                            <?php endif; ?>
                                            
                                            <?php if(!$device->approved): ?>
                                                <span class="text-danger">Access pending</span> <br>
                                            <?php endif; ?>
                                            <?php echo e($device->device_description); ?>

                                        </p>
                                        
                                        
                                    </div>
                                    <div class="card-footer">
                                        
                                        <?php if($data['manager']->contains('device_id' , $device->id)): ?>
                                            <a class="btn btn-primary" style="float: right" href='/manage/<?php echo e($device->uuid); ?>'>Manage</a>
                                        <?php else: ?>
                                        
                                            <?php if(!$device->approved && $device->invited_by): ?>
                                                
                                                <form action="/user/decline/<?php echo e($device->uuid); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input class="btn btn-danger" style="float: right" type="submit" value="Decline">
                                                </form>
                                                <form action="/user/accept/<?php echo e($device->uuid); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input class="btn btn-success" style="float: right" type="submit" value="Accept">
                                                </form>
                                            <?php else: ?>
                                                <form action="/user/decline/<?php echo e($device->uuid); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input class="btn btn-danger" style="float: right" type="submit" value="Abandon">
                                                </form>
                                            <?php endif; ?>
                                            
                                            
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                            <br>
                    </div>
    
    
                


            </div>
        </div>
        <div class="row flex-grow-1 bg-blue mapFlex">
            <div class="col">
                
                    <div id="map"></div>                
                
            </div>
        </div>
    </div>
    
    <div class="col-md-4 position-relative">

        <div class="w-95 position-absolute top-50 start-50 translate-middle flexHis">

            <h3 class="text-center">History</h3>
            <ul class="list-group m-1 hover-hover">
            <?php if(count($data['history'])): ?>

                <?php
                    $i = 0
                ?>
                
                    <?php $__currentLoopData = $data['history']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        <?php echo e($log->device_name); ?> 
                        <span class="badge bg-primary rounded-pill"><?php echo e($log->created_at->diffForHumans()); ?></span> 
                    </li>
                    <?php
                        $i++
                    ?>
                    <?php if($i > 10): ?>
                        <?php break; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover"><a href="/history">View full history</a></li>
                    
                    
            <?php else: ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">No history yet</li>
            <?php endif; ?>
            </ul>
                
            
        </div>

    </div>
</div>

<script src="js/map.js"></script>

<script>
    let devices_js = JSON.parse(<?php echo $data['deviceCoords']; ?>);
    console.log(devices_js);
</script>


<?php if(session('status')): ?>
    <script>
    alert( '<?php echo e(Session::get('status')); ?>' )
    </script>
<?php endif; ?>
<?php $__errorArgs = ['device_key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <script>alert("The code is invalid")</script>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/scenes/regular.blade.php ENDPATH**/ ?>