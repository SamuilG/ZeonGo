<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="/css/use.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row flex-grow-1">
    
    <div>

        <h2 class="text-center pt-3"><?php echo e($user->name); ?></h2>

        <h5 id="message"></h5>
        <br>
            
        <form action="/admin/updateUser/<?php echo e($user->uuid); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="form-group changeDeviceGroup"> 
                <label for="device_name" class="form-label">Change name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>">
            </div>

            <div class="form-group changeDeviceGroup"> 
                <label for="device_name" class="form-label">Change email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>">
            </div>

            
            
            <div class="form-group changeDeviceGroup">
                <label class="form-label" for="coordinates">Change password</label>
                <input type="text" class="form-control" id="password" name="password" value="">
            </div>

            <input type="submit" value="Update user" class="btn btn-primary">
        </form>
        <br>

        <div class="accordion-item">
            <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                Delete account
            </button>
            </h2>
            <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordion">
            <div class="accordion-body">
            
        
                <div id="buttons">
                    <a type='button' class='btn btn-primary' href="/admin/deleteUser/<?php echo e($user->uuid); ?>">Delete now</a>
                </div>


            </div>
            </div>
        </div>
        <br><br>

        <h3>Passes</h3>
        <table class="table">
            <thead>
              <tr>
                <th scope="col">Device key</th>
                <th scope="col">Device name</th>
                <th scope="col">Coordinates</th>
                <th scope="col">Approved</th>
                <th scope="col">Revoke pass</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $user->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($pass->device_key); ?></th>
                        <td><?php echo e($pass->device_name); ?></td>
                        <td><?php echo e($pass->coordinates); ?></td>
                        <td><?php if($pass->approved): ?>
                            Yes
                        <?php else: ?>
                            No
                        <?php endif; ?></td>
                        <td><a href="/admin/revoke/<?php echo e($pass->uuid); ?>/<?php echo e($user->uuid); ?>" class="btn btn-danger">Revoke</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <br><br>
  
          <h3>History</h3>
          <table class="table">
              <thead>
                <tr>
                    <th scope="col">Device key</th>
                    <th scope="col">Device name</th>
                    <th scope="col">Coordinates</th>
                  </tr>
                </thead>
                <tbody>
                    <?php
                        $i = 0
                    ?>
                    <?php $__currentLoopData = $user->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                            if($i > 10)
                            {
                                break;
                            }
                        ?>
                        <tr>
                            <td><?php echo e($history->device_name); ?></td>
                            <td><?php echo e($history->coordinates); ?></td>
                            <td><?php echo e($history->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
      
        </div>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/accountAdminSide.blade.php ENDPATH**/ ?>