<?php $__env->startSection('headContent'); ?>
    <link rel="stylesheet" href="/css/use.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($data['device']->device_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row flex-grow-1">
    
    <div class="col-md-6 d-flex h-100 flex-column h-resp">
        <div class="row info p-2">
            <div class="col h-100 h-resp">
                
                
                <form action="/manage/<?php echo e($data['device']->uuid); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group changeDeviceGroup"> 
                        <label for="device_name" class="form-label">Device name (<?php echo e($data['device']->device_key); ?>)</label>
                        <input type="text" class="form-control" id="device_name" name="device_name" value="<?php echo e($data['device']->device_name); ?>">
                    </div>

                    <div class="form-group changeDeviceGroup">
                        <label class="form-label" for="device_description">Device description</label>
                        <textarea class="form-control" rows="3" maxlength="600" id="device_description" name="device_description"><?php echo e($data['device']->device_description); ?></textarea>
                    </div>

                    <div class="form-group changeDeviceGroup">
                        <label class="form-label" for="coordinates">Device coordinates</label>
                        <input type="text" class="form-control" id="coordinates" name="coordinates" value="<?php echo e($data['device']->coordinates); ?>">
                    </div>
                    <input type="submit" value="Update" class="btn btn-primary float-end">
                </form>

            </div>
        </div>
        <div class="row flex-grow-1 p-2 bg-blue">
            <div class="col">
                
            <h3>History</h3>
            <ul class="list-group m-1">
                <?php if(count($data['history'])): ?>

                    <?php
                        $i = 0
                    ?>
                    
                        <?php $__currentLoopData = $data['history']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                            <?php echo e($log->email); ?> 
                            <span class="badge bg-primary rounded-pill"><?php echo e($log->created_at->diffForHumans()); ?></span> 
                        </li>
                        <?php
                            $i++
                        ?>
                        <?php if($i > 4): ?>
                            <?php break; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center this-hover"><a href="/history">View full history</a></li>
                        
                        
                <?php else: ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">No history yet</li>
                <?php endif; ?>
            </ul>

                

            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="">
            
            <h3 class="text-center">Members</h3>
                
                
                <ul class="list-group m-1">
                    <li class="list-group-item d-flex justify-content-between align-items-center this-hover">
                        <form class="w-100" action="/addUser/<?php echo e($data['device']->uuid); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            
                                <input class="btn btn-success float-end" type="submit" value="Add">
                                <input name="email" type="email" placeholder="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" class="w-50 form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                
                                <?php if(session('status')): ?>
                                    <div class="text-danger">User with this email doesn't exist</div>
                                <?php endif; ?>
                            
                            
                        </form>
                    </li>
                    <?php $__currentLoopData = $data['members']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center <?php if($data['managers']->contains('user_id' ,(int) $member->id) ): ?> bg-light <?php endif; ?> this-hover membersLi">
                            
                                <div class="w-37">
                                    <p class="m-0"><?php echo e($member->name); ?></p>                            
                                    <p class="m-0"><?php echo e($member->email); ?></p>
                                </div>

                                
                                
                                

                            
                            
                            <?php if(!$data['managers']->contains('user_id' ,(int) $member->id) ): ?>
                                <?php if($member->approved == true): ?>
                                    
                                    <form action="/decline/<?php echo e($data['device']->uuid); ?>/<?php echo e($member->uuid); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input class="btn btn-danger" type="submit" value="Evict">
                                    </form>
                                <?php else: ?>
                                    <?php if($member->invited_by): ?>
                                        <p class="btn btn-success">Wait for the user to decide</p>
                                    <?php else: ?>
                                        
                                        <form action="/approve/<?php echo e($data['device']->uuid); ?>/<?php echo e($member->uuid); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input class="btn btn-success" type="submit" value="Approve">
                                        </form>
                                        
                                        <form action="/decline/<?php echo e($data['device']->uuid); ?>/<?php echo e($member->uuid); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input class="btn btn-danger" type="submit" value="Decline">
                                        </form>
                                    <?php endif; ?>
                                    
                                <?php endif; ?>  
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/devices/manage.blade.php ENDPATH**/ ?>