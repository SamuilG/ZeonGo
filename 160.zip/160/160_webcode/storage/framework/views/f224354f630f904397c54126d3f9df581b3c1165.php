<?php $__env->startSection('title'); ?>
    <?php if($device->device_name): ?> 
    Editing 
    <?php else: ?>
    Creating
    <?php endif; ?> Device    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-10 bg-light" style="height: 100vh; overflow-x: hidden;">
    <div class="bg-light row">
        <h1 class="mx-4 my-3 col-4"><i class="fa fa-video"></i>
            <?php if($device->device_name): ?> 
                Editing 
            <?php else: ?>
                Creating
            <?php endif; ?> Device</h1>
    </div>
    <br><br><br>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success mx-auto col-4" role="alert">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <div class="card col-11 mx-auto py-4">
        <form action="<?php if($device->device_name): ?> /admin/devices/update/<?php echo e($device->uuid); ?> <?php else: ?> store <?php endif; ?>" method="POST">
            <?php if($device->device_name): ?>
                <?php echo method_field('put'); ?>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Name
                            <span class="required">*</span>
                        </label>
                        <input type="text" name="device_name"
                            class="form-control <?php $__errorArgs = ['device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('device_name', $device->device_name)); ?>"
                        >
                        <?php $__errorArgs = ['device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                    </div>
                </div>
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Coordinates
                            <span class="required">*</span>
                        </label>
                        <input
                            type="text"
                            name="coordinates"
                            class="form-control <?php $__errorArgs = ['coordinates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('coordinates', $device->coordinates)); ?>"
                        >
                        <?php $__errorArgs = ['coordinates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Description
                            <span class="required">*</span>
                        </label>
                        <textarea
                            type="text"
                            name="device_description"
                            rows="3"
                            class="form-control <?php $__errorArgs = ['device_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('device_description')); ?>"
                        ><?php echo e(old('device_description', $device->device_description)); ?></textarea>
                        <?php $__errorArgs = ['device_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4 ms-auto mt-4">
                    <input class="btn btn-success float-end mx-4" type="submit" value="Save">
                    <a href="/admin/devices" class="btn btn-danger float-end mx-4">Back</a>
                </div>
            </div>
        </form>
    </div>

    <?php if($device->device_name): ?>
        <div class="card col-11 mx-auto px-4 py-4 my-4">
            
            <div id="containAccordion" class="row">

                <h5 id="message">Device Info</h5>
                <br>
                <div class="accordion" id="accordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#users" aria-expanded="false" aria-controls="collapseOne">
                            Users
                        </button>
                        </h2>
                        <div id="users" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>User id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Since</th>
                                    <th>Entries</th>
                                    <th>Remove</th>
                                </tr>
                                <tr>
                                    <td colspan="6" style="text-align: center"><a class="btn btn-primary col-4" href="/admin/devices/<?php echo e($device->uuid); ?>/passes/create/">Add a new user</a></td>
                                </tr>
                                <?php $__currentLoopData = $device->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->created_at); ?></td>
                                        <td><?php echo e($device->history->where('email', $user->email)->count()); ?></td>
                                        <td>
                                            <form action="/admin/devices/<?php echo e($device->uuid); ?>/passes/destroy/<?php echo e($user->uuid); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove user">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#managers" aria-expanded="false" aria-controls="collapseOne">
                            Managers
                        </button>
                        </h2>
                        <div id="managers" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>User id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Since</th>
                                    <th>Remove</th>
                                </tr>
                                <tr>
                                    <td colspan="6" style="text-align: center"><a class="btn btn-primary col-4" href="/admin/devices/<?php echo e($device->uuid); ?>/managers/create/">Add a new manager</a></td>
                                </tr> 
                                <?php $__currentLoopData = $device->managersFullData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($manager->user->id); ?></td>
                                        <td><?php echo e($manager->user->name); ?></td>
                                        <td><?php echo e($manager->user->email); ?></td>
                                        <td><?php echo e($manager->created_at); ?></td>
                                        <td>
                                            <form action="/admin/devices/<?php echo e($device->uuid); ?>/managers/destroy/<?php echo e($manager->user_id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove manager">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#history" aria-expanded="false" aria-controls="collapseOne">
                            Access history
                        </button>
                        </h2>
                        <div id="history" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>Log id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Remove</th>
                                </tr>
                                <?php $__currentLoopData = $device->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($log->id); ?></td>
                                        <td><?php echo e($log->name); ?></td>
                                        <td><?php echo e($log->email); ?></td>
                                        <td><?php echo e($log->created_at); ?></td>
                                        <td>
                                            <form action="/admin/devices/<?php echo e($device->uuid); ?>/history/destroy/<?php echo e($log->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove log">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php endif; ?>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/devices/form.blade.php ENDPATH**/ ?>