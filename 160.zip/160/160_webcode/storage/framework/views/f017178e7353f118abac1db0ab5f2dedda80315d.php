<?php $__env->startSection('title'); ?>
    <?php if($user->email): ?> 
    Editing 
    <?php else: ?>
    Creating
    <?php endif; ?> User   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-10 bg-light" style="height: 100vh; overflow-x: hidden;">
    <div class="bg-light row">
        <h1 class="mx-4 my-3 col-4"><i class="fa fa-user"></i>
            <?php if($user->email): ?> 
                Editing 
            <?php else: ?>
                Creating
            <?php endif; ?> User</h1>
    </div>
    <br><br><br>
    <?php if(session()->has('success')): ?>
        <div class="alert alert-success mx-auto col-4" role="alert">
            <?php echo e(session()->get('success')); ?>

        </div>
    <?php endif; ?>
    <div class="card col-11 mx-auto py-4">
        <form action="<?php if($user->email): ?> /admin/users/update/<?php echo e($user->uuid); ?> <?php else: ?> store <?php endif; ?>" method="POST">
            <?php if($user->email): ?>
                <?php echo method_field('put'); ?>
            <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Email
                            <span class="required">*</span>
                        </label>
                        <input type="email" name="email"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('email', $user->email)); ?>"
                            <?php if($user->email): ?>
                                disabled
                            <?php endif; ?>
                        >
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        
                    </div>
                </div>
                <div class="col-6 px-4">
                    <div class="form-group">
                        <label class="col-form-label">
                            Name
                            <span class="required">*</span>
                        </label>
                        <input
                            type="text"
                            name="name"
                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('name', $user->name)); ?>"
                        >
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <?php if(!$user->email): ?>
                <div class="row">
                    <div class="col-6 px-4">
                        <div class="form-group">
                            <label class="col-form-label">
                                Password
                                <span class="required">*</span>
                            </label>
                            <input
                                type="text"
                                name="password"
                                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('password')); ?>"
                            >
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-4 ms-auto mt-4">
                    <input class="btn btn-success float-end mx-4" type="submit" value="Save">
                    <a href="/admin/users" class="btn btn-danger float-end mx-4">Back</a>
                </div>
            </div>
        </form>
    </div>

    <?php if($user->email): ?>
        <div class="card col-11 mx-auto px-4 py-4 my-4">
            
            <div id="containAccordion" class="row">

                <h5 id="message">User Info</h5>
                <br>
                <div class="accordion" id="accordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#passes" aria-expanded="false" aria-controls="collapseOne">
                            Passes
                        </button>
                        </h2>
                        <div id="passes" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>Device Name</th>
                                    <th>Device Coordinates</th>
                                    <th>Since</th>
                                    <th>Entries</th>
                                    <th>Remove</th>
                                </tr>
                                <tr>
                                    <td colspan="6" style="text-align: center"><a class="btn btn-primary col-4" href="/admin/users/<?php echo e($user->uuid); ?>/passes/create/">Add a new pass</a></td>
                                </tr>
                                <?php $__currentLoopData = $user->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($device->device_name); ?></td>
                                        <td><?php echo e($device->coordinates); ?></td>
                                        <td><?php echo e($device->created_at); ?></td>
                                        <td><?php echo e($user->history->where('device_id', $device->device_id)->count()); ?></td>
                                        <td>
                                            <form action="/admin/users/<?php echo e($user->uuid); ?>/passes/destroy/<?php echo e($device->uuid); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove pass">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#manages" aria-expanded="false" aria-controls="collapseOne">
                            Manages
                        </button>
                        </h2>
                        <div id="manages" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>Device Name</th>
                                    <th>Device Coordinates</th>
                                    <th>Since</th>
                                    <th>Remove</th>
                                </tr>
                                <tr>
                                    <td colspan="6" style="text-align: center"><a class="btn btn-primary col-4" href="/admin/users/<?php echo e($user->uuid); ?>/managers/create/">Add a new device to manage</a></td>
                                </tr>
                                <?php $__currentLoopData = $user->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($manager->device->device_name); ?></td>
                                        <td><?php echo e($manager->device->coordinates); ?></td>
                                        <td><?php echo e($manager->created_at); ?></td>
                                        <td>
                                            <form action="/admin/users/<?php echo e($user->uuid); ?>/managers/destroy/<?php echo e($manager->device->uuid); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove manager">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#history" aria-expanded="false" aria-controls="collapseOne">
                            History
                        </button>
                        </h2>
                        <div id="history" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordion">
                        <div class="accordion-body">
                            
                            <table class="col-12 table table-striped">
                                <tr>
                                    <th>Device Name</th>
                                    <th>Device Coordinates</th>
                                    <th>Date</th>
                                    <th>Remove</th>
                                </tr>
                                <?php $__currentLoopData = $user->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($log->device_name); ?></td>
                                        <td><?php echo e($log->coordinates); ?></td>
                                        <td><?php echo e($log->created_at); ?></td>
                                        <td>
                                            <form action="/admin/users/<?php echo e($user->uuid); ?>/history/destroy/<?php echo e($log->history_id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input type="submit" class="btn btn-danger" value="Remove history">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>     
                            
                        </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    <?php endif; ?>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/admin/users/form.blade.php ENDPATH**/ ?>