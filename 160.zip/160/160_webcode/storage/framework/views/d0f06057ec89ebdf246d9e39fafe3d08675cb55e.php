<?php $__env->startSection('emailBody'); ?>
    
    <a class="button" role="button" href="http://127.0.0.1:8000/verifyEmail?key=<?php echo e($data['verifyKey']); ?>" aria-disabled="true">Verify your email</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ilko/Documents/ZeonGo/resources/views/emails/emailVerify.blade.php ENDPATH**/ ?>