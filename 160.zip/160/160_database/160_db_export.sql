-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 10 март 2022 в 21:45
-- Версия на сървъра: 5.7.33-36
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `00582288_zeongo`
--

-- --------------------------------------------------------

--
-- Структура на таблица `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `admins`
--

INSERT INTO `admins` (`id`, `user_id`, `created_at`, `updated_at`) VALUES
(5, 36, '2022-01-24 13:21:31', '2022-01-24 13:21:31');

-- --------------------------------------------------------

--
-- Структура на таблица `devices`
--

CREATE TABLE `devices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `coordinates` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `devices`
--

INSERT INTO `devices` (`id`, `uuid`, `device_name`, `device_description`, `coordinates`, `device_key`, `created_at`, `updated_at`) VALUES
(10, 'f3a07bf2-a40a-4723-b91e-b90de46c38bf', 'Офис', 'Потребителят има достъп до това устройство и може да го вижда', '43.56578983848722, 27.818980167086856', 'CSczg7', '2022-03-06 15:40:22', '2022-03-09 16:35:57'),
(11, '9e5bd4e7-6fe0-486a-852f-287b318c0b41', 'Лаборатория', 'Потребителят има достъп до този акаунт и предоставеният мениджър профил може да го управлява', '43.564064714040505, 27.82895832474051', 'gS3GQe', '2022-03-06 15:42:50', '2022-03-09 17:09:37');

-- --------------------------------------------------------

--
-- Структура на таблица `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура на таблица `history`
--

CREATE TABLE `history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `device_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `history`
--

INSERT INTO `history` (`id`, `user_id`, `device_id`, `created_at`, `updated_at`) VALUES
(6, 34, 11, '2022-03-08 15:26:23', '2022-03-08 15:26:23'),
(7, 34, 11, '2022-03-08 15:26:36', '2022-03-08 15:26:36'),
(8, 34, 11, '2022-03-08 15:30:50', '2022-03-08 15:30:50'),
(9, 34, 11, '2022-03-08 15:32:21', '2022-03-08 15:32:21'),
(10, 34, 11, '2022-03-08 15:33:49', '2022-03-08 15:33:49'),
(11, 34, 11, '2022-03-08 15:34:16', '2022-03-08 15:34:16'),
(12, 34, 11, '2022-03-08 15:34:25', '2022-03-08 15:34:25'),
(13, 34, 11, '2022-03-08 15:36:06', '2022-03-08 15:36:06'),
(14, 34, 11, '2022-03-08 15:36:36', '2022-03-08 15:36:36'),
(15, 34, 11, '2022-03-08 15:36:47', '2022-03-08 15:36:47'),
(16, 34, 11, '2022-03-08 15:41:33', '2022-03-08 15:41:33'),
(17, 34, 11, '2022-03-08 15:41:49', '2022-03-08 15:41:49'),
(18, 34, 11, '2022-03-08 15:42:03', '2022-03-08 15:42:03'),
(19, 34, 11, '2022-03-08 15:43:08', '2022-03-08 15:43:08'),
(20, 34, 11, '2022-03-08 15:43:16', '2022-03-08 15:43:16'),
(21, 34, 11, '2022-03-08 15:43:29', '2022-03-08 15:43:29'),
(22, 34, 11, '2022-03-08 15:44:05', '2022-03-08 15:44:05'),
(23, 34, 11, '2022-03-08 15:44:13', '2022-03-08 15:44:13'),
(24, 34, 11, '2022-03-08 15:44:26', '2022-03-08 15:44:26'),
(25, 34, 11, '2022-03-08 15:44:59', '2022-03-08 15:44:59'),
(26, 34, 11, '2022-03-08 15:45:17', '2022-03-08 15:45:17'),
(27, 34, 11, '2022-03-08 15:45:54', '2022-03-08 15:45:54'),
(28, 34, 11, '2022-03-08 15:46:26', '2022-03-08 15:46:26'),
(29, 34, 11, '2022-03-08 15:46:34', '2022-03-08 15:46:34'),
(30, 34, 11, '2022-03-08 15:48:33', '2022-03-08 15:48:33'),
(31, 34, 11, '2022-03-08 15:49:28', '2022-03-08 15:49:28'),
(32, 34, 11, '2022-03-08 15:53:55', '2022-03-08 15:53:55'),
(33, 34, 11, '2022-03-08 15:54:12', '2022-03-08 15:54:12'),
(34, 34, 11, '2022-03-08 15:54:21', '2022-03-08 15:54:21'),
(35, 34, 11, '2022-03-08 15:54:28', '2022-03-08 15:54:28'),
(36, 34, 11, '2022-03-08 15:55:14', '2022-03-08 15:55:14'),
(37, 34, 11, '2022-03-08 16:03:38', '2022-03-08 16:03:38'),
(38, 34, 11, '2022-03-08 16:04:14', '2022-03-08 16:04:14'),
(39, 34, 11, '2022-03-08 16:07:07', '2022-03-08 16:07:07'),
(40, 34, 11, '2022-03-08 16:23:03', '2022-03-08 16:23:03'),
(41, 34, 11, '2022-03-08 16:23:45', '2022-03-08 16:23:45'),
(42, 34, 11, '2022-03-08 16:25:59', '2022-03-08 16:25:59'),
(43, 34, 11, '2022-03-08 16:38:41', '2022-03-08 16:38:41'),
(44, 34, 11, '2022-03-08 16:41:48', '2022-03-08 16:41:48'),
(45, 34, 11, '2022-03-08 16:55:25', '2022-03-08 16:55:25'),
(46, 34, 11, '2022-03-08 16:55:37', '2022-03-08 16:55:37'),
(47, 34, 11, '2022-03-08 16:57:25', '2022-03-08 16:57:25'),
(48, 34, 11, '2022-03-08 16:57:43', '2022-03-08 16:57:43'),
(49, 34, 11, '2022-03-08 16:57:48', '2022-03-08 16:57:48'),
(50, 34, 11, '2022-03-09 14:11:07', '2022-03-09 14:11:07'),
(51, 34, 11, '2022-03-09 14:11:17', '2022-03-09 14:11:17'),
(52, 34, 11, '2022-03-09 17:06:40', '2022-03-09 17:06:40'),
(53, 34, 11, '2022-03-09 17:06:56', '2022-03-09 17:06:56'),
(54, 34, 11, '2022-03-09 17:07:05', '2022-03-09 17:07:05'),
(55, 34, 11, '2022-03-09 17:07:38', '2022-03-09 17:07:38'),
(56, 34, 11, '2022-03-09 17:07:53', '2022-03-09 17:07:53'),
(57, 34, 11, '2022-03-09 17:08:43', '2022-03-09 17:08:43'),
(58, 34, 11, '2022-03-09 17:09:10', '2022-03-09 17:09:10'),
(59, 34, 11, '2022-03-09 17:10:04', '2022-03-09 17:10:04'),
(60, 34, 11, '2022-03-09 17:10:14', '2022-03-09 17:10:14'),
(61, 34, 11, '2022-03-09 17:11:19', '2022-03-09 17:11:19'),
(62, 34, 11, '2022-03-09 17:11:31', '2022-03-09 17:11:31'),
(63, 34, 11, '2022-03-10 14:23:33', '2022-03-10 14:23:33'),
(64, 34, 11, '2022-03-10 14:23:44', '2022-03-10 14:23:44'),
(65, 34, 11, '2022-03-10 14:26:31', '2022-03-10 14:26:31'),
(66, 34, 11, '2022-03-10 14:26:37', '2022-03-10 14:26:37'),
(67, 34, 11, '2022-03-10 18:35:13', '2022-03-10 18:35:13'),
(68, 34, 11, '2022-03-10 18:35:24', '2022-03-10 18:35:24');

-- --------------------------------------------------------

--
-- Структура на таблица `managers`
--

CREATE TABLE `managers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `device_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `managers`
--

INSERT INTO `managers` (`id`, `user_id`, `device_id`, `created_at`, `updated_at`) VALUES
(11, 35, 11, '2022-03-06 15:43:24', '2022-03-06 15:43:24');

-- --------------------------------------------------------

--
-- Структура на таблица `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_11_11_150502_create_codes_table', 1),
(6, '2021_11_12_153618_create_devices_table', 1),
(7, '2021_11_12_155208_create_passes_table', 1),
(8, '2021_11_17_164821_create_history_table', 1),
(9, '2021_12_08_132513_create_managers_table', 1),
(10, '2022_01_14_142316_add_uuid_column_to_users_table', 1),
(11, '2022_01_17_141908_add_invite_type_column_to_passes_table', 1),
(12, '2022_01_24_140141_create_admins_table', 2);

-- --------------------------------------------------------

--
-- Структура на таблица `passes`
--

CREATE TABLE `passes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `device_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `approved` tinyint(1) NOT NULL,
  `invited_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `passes`
--

INSERT INTO `passes` (`id`, `device_id`, `user_id`, `approved`, `invited_by`, `approved_by`, `created_at`, `updated_at`) VALUES
(42, 10, 34, 1, NULL, NULL, '2022-03-06 15:43:02', '2022-03-06 15:43:02'),
(43, 11, 34, 1, NULL, NULL, '2022-03-06 15:43:14', '2022-03-06 15:43:14'),
(44, 11, 35, 1, NULL, NULL, '2022-03-06 15:43:24', '2022-03-06 15:43:24');

-- --------------------------------------------------------

--
-- Структура на таблица `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура на таблица `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `users`
--

INSERT INTO `users` (`id`, `uuid`, `name`, `email`, `email_verified`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(34, '08ec80cc-ba8d-47f7-9efd-326c548fa457', 'User ZeonGo', 'user@zeongo.online', '1', '$2y$10$LH/r3zi0dB1VTiKOm6OCUeBUkRsGENUGBK1dfvq7AHXWYjGtYSoPK', 'YONnjKPShlSudqYBU0NsOiV3S5sKLsxEvwx1D3nRToUfwoVtiFiWQmqCrjp9', '2022-03-06 15:35:38', '2022-03-06 15:35:38'),
(35, '357968a5-982f-4bc5-8acc-035c978fefb5', 'Manager ZeonGo', 'manager@zeongo.online', '1', '$2y$10$rH7XsjbHf2t8SXb4kRtVQOdji0Wcc9adfekMz3gPoo3VWxp3vW5ue', NULL, '2022-03-06 15:36:08', '2022-03-06 15:36:08'),
(36, '177a2b09-12aa-4e6c-86be-9b4c5c638a6c', 'Admin ZeonGo', 'admin@zeongo.online', '1', '$2y$10$MIE2r3u.6oWg4UfMk0MJQuKn6zex.F9b2kClA6WkJX1GGb7NGXGpK', NULL, '2022-03-06 15:37:39', '2022-03-06 15:50:07'),
(37, '3ecb994e-343e-4a18-bc11-dfc59a20c324', 'Илиян Петров', 'ilko.petrov27@gmail.com', '1', '$2y$10$kFrKifKHfqE1HjhGUf9Aa.OlWEYOsSUWp8cRUso/fTvgALE92Pco2', NULL, '2022-03-08 13:33:57', '2022-03-09 17:02:41');

-- --------------------------------------------------------

--
-- Структура на таблица `user_keys`
--

CREATE TABLE `user_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_key` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Схема на данните от таблица `user_keys`
--

INSERT INTO `user_keys` (`key_id`, `user_id`, `user_key`, `created_at`, `updated_at`) VALUES
(13, 34, 'nHAZ8XBnQqZKdIHoee93yj1axGs2zCkBRSO77Nnn52FvkHj2gYSJMuSrwYknoDCX0AViMiacrRSogCG2Zeb3dnIDIbK9YJYTBj3G', '2022-03-06 15:35:38', '2022-03-10 19:39:46'),
(14, 35, 'AMT4dqw9XTxgt2z2H1CD5w9sLUI8HYydDlHusWBVtfMkz6o0oVi5GIS8xDtQZALizcMet8q9UDVNDTSmrorkXN2HSJjN7L709uBj', '2022-03-06 15:36:08', '2022-03-06 15:46:21'),
(15, 36, 'ql9GNxub8EgRs9KXwURpgyUu4K2CSaokOGxrTUfRPjHhoVHBu4wzHubb3eip9KIEw7BhkTGqjzsbPO361wr1LoxCcNnemjznYau2', '2022-03-06 15:37:39', '2022-03-10 16:22:36'),
(16, 37, 'ZoJj5Ipj4vw0iTNIcdCJ5ovzgWcB2VexIwX1rDM0Ac2hLBV0SwlPW6zwBDXLdsHF6tHOUOecSveLKiJZljhNju2Nn6gmoe1N1NHe', '2022-03-08 13:33:57', '2022-03-08 15:23:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admins_user_id_foreign` (`user_id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `history_user_id_foreign` (`user_id`),
  ADD KEY `history_device_id_foreign` (`device_id`);

--
-- Indexes for table `managers`
--
ALTER TABLE `managers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `managers_user_id_foreign` (`user_id`),
  ADD KEY `managers_device_id_foreign` (`device_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `passes`
--
ALTER TABLE `passes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `passes_device_id_foreign` (`device_id`),
  ADD KEY `passes_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_keys`
--
ALTER TABLE `user_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `user_keys_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `managers`
--
ALTER TABLE `managers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `passes`
--
ALTER TABLE `passes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `user_keys`
--
ALTER TABLE `user_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения за таблица `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения за таблица `managers`
--
ALTER TABLE `managers`
  ADD CONSTRAINT `managers_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `managers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения за таблица `passes`
--
ALTER TABLE `passes`
  ADD CONSTRAINT `passes_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `passes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения за таблица `user_keys`
--
ALTER TABLE `user_keys`
  ADD CONSTRAINT `user_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
