import cv2
import time
import webbrowser
import requests
from termcolor import colored
from pyzbar import pyzbar


def read_barcodes(frame):
    barcodes = pyzbar.decode(frame)
    for barcode in barcodes:
        x, y, w, h = barcode.rect

        barcode_info = barcode.data.decode('utf-8')
        if len(barcode_info) != 100:
            print(colored('Невалиден код', 'white', 'on_red'))
            continue
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, barcode_info, (x + 6, y - 6), font, 1.0, (255, 255, 255), 1)

        r = requests.post('https://zeongo.online/api/process', data={'userKey': barcode_info, 'device_key': 'gS3GQe'})
        # print(r.text)
        if r.text == '1':
            print(colored('Потребителят може да премине', 'white', 'on_green'))
            return frame ,True
        elif r.text == '0':
            print(colored('Достъп отказан', 'white', 'on_red'))
            return frame ,False
        elif r.text == '2':
            print(colored('Код изтекъл', 'white', 'on_red'))
            return frame ,False
    return frame, False



def main():
    camera = cv2.VideoCapture(0)
    while True:
        ret, frame = camera.read()

        frame = cv2.flip(frame, 45)

        frame, approved = read_barcodes(frame)
        
        cv2.imshow('ZeonGo Scan', frame)

        if approved == True:
            time.sleep(2)
            camera.release()
            camera = cv2.VideoCapture(0)

            continue
        if cv2.waitKey(1) & 0xFF == 27:
            break

if __name__ == '__main__':
    print(colored(' _____                ', 'blue') + ' ____       ')
    print(colored('|__  /___  ___  _ __  ', 'blue') + '/ ___| ___  ')
    print(colored('  / // _ \/ _ \| \'_ \\', 'blue') +'| |  _ / _ \ ')
    print(colored(' / /|  __/ (_) | | | |', 'blue') + ' |_| | (_) |')
    print(colored('/____\___|\___/|_| |_|', 'blue') + '\____|\___/ ')

    print("Device: Office")
    main()
